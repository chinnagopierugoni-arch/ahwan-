import { useState } from "react";
import {
  Menu, X, ArrowUpRight, ArrowRight,
  MapPin, Clock, Phone, Utensils
} from "lucide-react";
import { motion } from "framer-motion";

const dishes = [
  {
    name: "Signature Biryani",
    category: "INDIAN SPECIAL",
    image: "https://images.unsplash.com/photo-1563379091339-03246963d96c?w=900",
    description: "Aromatic rice and carefully selected spices."
  },
  {
    name: "Royal Platter",
    category: "CHEF'S SELECTION",
    image: "https://images.unsplash.com/photo-1544025162-d76694265947?w=900",
    description: "A selection of delicious restaurant favourites."
  },
  {
    name: "Grilled Special",
    category: "FROM THE GRILL",
    image: "https://images.unsplash.com/photo-1555939594-58d7cb561ad1?w=900",
    description: "Freshly prepared and served with signature sides."
  }
];

const navLinks = [
  ["Home", "#home"],
  ["Our Story", "#story"],
  ["Menu", "#menu"],
  ["Gallery", "#gallery"],
  ["Contact", "#contact"]
];

function Navbar() {
  const [open, setOpen] = useState(false);

  return (
    <header className="fixed inset-x-0 top-0 z-50 border-b border-white/10 bg-[#151411]/90 backdrop-blur-xl">
      <nav className="mx-auto flex max-w-7xl items-center justify-between px-6 py-5">
        <a href="#home" aria-label="Ahwan Restaurant home" className="text-center font-serif text-2xl tracking-[0.2em] text-[#d7b77a]">
          AHWAN
          <span className="block font-sans text-[9px] tracking-[0.4em] text-white/60">RESTAURANT</span>
        </a>

        <div className="hidden items-center gap-9 md:flex">
          {navLinks.map(([label, href]) => (
            <a key={label} href={href} className="text-xs uppercase tracking-widest text-white/70 transition hover:text-[#d7b77a]">
              {label}
            </a>
          ))}
        </div>

        <a href="#menu" className="hidden items-center gap-3 bg-[#c49a55] px-5 py-3 text-xs uppercase tracking-widest text-black transition hover:bg-[#e0bd7d] md:flex">
          Explore Menu <ArrowUpRight size={15} />
        </a>

        <button className="text-white md:hidden" onClick={() => setOpen(!open)} aria-label="Toggle navigation" aria-expanded={open}>
          {open ? <X /> : <Menu />}
        </button>
      </nav>

      {open && (
        <div className="flex flex-col gap-5 border-t border-white/10 bg-[#151411] px-6 pb-6 md:hidden">
          {navLinks.map(([label, href]) => (
            <a key={label} href={href} onClick={() => setOpen(false)} className="text-sm uppercase tracking-widest text-white/80">
              {label}
            </a>
          ))}
        </div>
      )}
    </header>
  );
}

function Hero() {
  return (
    <section id="home" className="relative flex min-h-[90vh] items-center overflow-hidden">
      <img
        src="https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?w=2000"
        alt="Elegant restaurant interior"
        className="absolute inset-0 h-full w-full object-cover opacity-45"
      />
      <div className="absolute inset-0 bg-gradient-to-r from-[#151411] via-[#151411]/75 to-black/20" />
      <div className="relative z-10 mx-auto w-full max-w-7xl px-6 pb-24 pt-32">
        <motion.div initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.9 }} className="max-w-3xl">
          <p className="mb-8 text-xs tracking-[0.4em] text-[#d7b77a]">AN EXPERIENCE BEYOND TASTE</p>
          <h1 className="font-serif text-6xl leading-[1.05] sm:text-7xl md:text-8xl">
            A world of<br /><span className="italic text-[#d7b77a]">flavours</span><br />awaits you.
          </h1>
          <p className="mt-8 max-w-lg text-sm leading-8 text-white/65 sm:text-base">
            Discover a thoughtfully curated multi-cuisine experience, where every dish brings people together.
          </p>
          <div className="mt-10 flex flex-wrap gap-4">
            <a href="#menu" className="flex items-center gap-3 bg-[#c49a55] px-7 py-4 text-xs uppercase tracking-widest text-black transition hover:bg-[#e0bd7d]">
              Discover Our Menu <ArrowRight size={16} />
            </a>
            <a href="#contact" className="border border-white/40 px-7 py-4 text-xs uppercase tracking-widest transition hover:border-[#d7b77a] hover:text-[#d7b77a]">
              Visit Us
            </a>
          </div>
        </motion.div>
      </div>
      <div className="absolute bottom-8 right-8 hidden text-[10px] tracking-[0.3em] text-white/50 [writing-mode:vertical-rl] md:block">
        BTM LAYOUT · BENGALURU
      </div>
    </section>
  );
}

function Intro() {
  return (
    <section id="story" className="mx-auto grid max-w-7xl items-center gap-16 px-6 py-28 md:grid-cols-2">
      <div className="relative">
        <img src="https://images.unsplash.com/photo-1414235077428-338989a2e8c0?w=1000" alt="Fine dining experience" className="h-[480px] w-full object-cover" />
        <div className="absolute -bottom-5 -right-5 hidden bg-[#c49a55] p-7 text-black sm:block">
          <p className="font-serif text-3xl">AHWAN</p>
          <p className="mt-2 text-[9px] tracking-widest">A TASTE TO REMEMBER</p>
        </div>
      </div>
      <div>
        <p className="mb-6 text-xs tracking-[0.4em] text-[#d7b77a]">OUR STORY</p>
        <h2 className="font-serif text-5xl leading-tight">Where taste meets <span className="italic text-[#d7b77a]">elegance.</span></h2>
        <p className="mt-7 text-sm leading-8 text-white/60">
          Welcome to Ahwan Restaurant. A place designed for memorable meals, warm hospitality and a journey through diverse flavours.
        </p>
        <p className="mt-4 text-sm leading-8 text-white/60">
          From everyday favourites to special dining moments, discover a menu created to bring people together.
        </p>
        <a href="#menu" className="mt-9 inline-flex items-center gap-3 text-xs uppercase tracking-widest text-[#d7b77a]">
          Explore Our Menu <ArrowUpRight size={16} />
        </a>
      </div>
    </section>
  );
}

function MenuSection() {
  return (
    <section id="menu" className="bg-[#1d1b17] px-6 py-28">
      <div className="mx-auto max-w-7xl">
        <div className="mb-16 text-center">
          <p className="mb-5 text-xs tracking-[0.4em] text-[#d7b77a]">A CURATED SELECTION</p>
          <h2 className="font-serif text-5xl sm:text-6xl">Our Signature Menu</h2>
          <p className="mt-5 text-sm text-white/50">Discover the flavours that make every visit special.</p>
        </div>
        <div className="grid gap-7 sm:grid-cols-2 lg:grid-cols-3">
          {dishes.map((dish, index) => (
            <motion.article key={dish.name} initial={{ opacity: 0, y: 25 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ delay: index * 0.15 }} className="group border border-white/10 bg-[#151411]">
              <div className="overflow-hidden">
                <img src={dish.image} alt={dish.name} className="h-64 w-full object-cover transition duration-700 group-hover:scale-105" />
              </div>
              <div className="p-7">
                <p className="text-[10px] tracking-[0.3em] text-[#c49a55]">{dish.category}</p>
                <h3 className="mt-4 font-serif text-2xl">{dish.name}</h3>
                <p className="mt-4 text-sm text-white/50">{dish.description}</p>
              </div>
            </motion.article>
          ))}
        </div>
        <p className="mt-8 text-center text-xs text-white/40">Sample design content. Final menu and prices will be supplied by the restaurant.</p>
      </div>
    </section>
  );
}

function Gallery() {
  const photos = [
    ["photo-1547592180-85f173990554", "Food presentation"],
    ["photo-1544025162-d76694265947", "Restaurant dish"],
    ["photo-1555939594-58d7cb561ad1", "Grilled food"],
    ["photo-1517248135467-4c7edcad34c4", "Restaurant interior"]
  ];

  return (
    <section id="gallery" className="mx-auto max-w-7xl px-6 py-28">
      <div className="mb-14 text-center">
        <p className="mb-5 text-xs tracking-[0.4em] text-[#d7b77a]">THE AHWAN EXPERIENCE</p>
        <h2 className="font-serif text-5xl">A feast for the senses.</h2>
      </div>
      <div className="grid grid-cols-2 gap-3 md:grid-cols-4">
        {photos.map(([photo, label], index) => (
          <img key={photo} src={`https://images.unsplash.com/${photo}?w=700`} alt={label} className={`w-full object-cover transition hover:opacity-75 ${index % 2 === 0 ? "h-64" : "h-80"}`} />
        ))}
      </div>
    </section>
  );
}

function Contact() {
  return (
    <section id="contact" className="bg-[#1d1b17] px-6 py-24">
      <div className="mx-auto grid max-w-7xl gap-12 md:grid-cols-2">
        <div>
          <p className="mb-5 text-xs tracking-[0.4em] text-[#d7b77a]">COME FIND US</p>
          <h2 className="font-serif text-5xl">Your table of flavours awaits.</h2>
          <p className="mt-6 text-sm leading-8 text-white/55">Visit Ahwan Restaurant in BTM Layout, Bengaluru. We look forward to welcoming you.</p>
          <div className="mt-9 space-y-5 text-sm text-white/70">
            <p className="flex items-center gap-3"><MapPin className="text-[#d7b77a]" /> BTM Layout, Bengaluru, Karnataka</p>
            <p className="flex items-center gap-3"><Clock className="text-[#d7b77a]" /> Opening hours to be confirmed</p>
            <p className="flex items-center gap-3"><Phone className="text-[#d7b77a]" /> Restaurant contact to be added</p>
          </div>
        </div>
        <div className="flex min-h-[300px] flex-col items-center justify-center border border-white/10 p-8 text-center">
          <Utensils size={35} className="text-[#d7b77a]" />
          <h3 className="mt-6 font-serif text-3xl">Order for takeaway</h3>
          <p className="mt-4 max-w-sm text-sm leading-7 text-white/50">Explore our menu and enjoy your favourite dishes. Online ordering will be available soon.</p>
          <a href="#menu" className="mt-7 bg-[#c49a55] px-7 py-4 text-xs uppercase tracking-widest text-black">Explore Menu</a>
        </div>
      </div>
    </section>
  );
}

function Footer() {
  return (
    <footer className="border-t border-white/10 px-6 py-12">
      <div className="mx-auto flex max-w-7xl flex-col items-center justify-between gap-6 md:flex-row">
        <div className="text-center md:text-left">
          <p className="font-serif text-2xl tracking-[0.2em] text-[#d7b77a]">AHWAN</p>
          <p className="mt-2 text-[9px] tracking-[0.3em] text-white/40">RESTAURANT</p>
        </div>
        <p className="text-xs text-white/40">© {new Date().getFullYear()} Ahwan Restaurant. All rights reserved.</p>
        <p className="text-xs tracking-widest text-white/50">POWERED BY ZENTRO TECHNOLOGIES</p>
      </div>
    </footer>
  );
}

export default function App() {
  return (
    <main className="overflow-hidden bg-[#151411] text-[#f5f0e8]">
      <Navbar />
      <Hero />
      <Intro />
      <MenuSection />
      <Gallery />
      <Contact />
      <Footer />
    </main>
  );
}
