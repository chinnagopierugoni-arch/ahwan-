# Ahwan Restaurant — Phase 1 UI

Premium, responsive restaurant website starter built with React, Vite, Tailwind CSS v4, Framer Motion and Lucide icons.

## Requirements
- Node.js 20.19+ or 22.12+
- npm

## Run locally
1. Extract the ZIP.
2. Open the `ahwan-restaurant` folder in VS Code.
3. Open Terminal → New Terminal.
4. Run:

```bash
npm install
npm run dev
```

5. Open the local URL printed by Vite (usually http://localhost:5173).

## Production build
```bash
npm run build
npm run preview
```

## Current scope
This ZIP contains Phase 1: the customer-facing visual homepage only. It is not yet connected to a backend, live menu, shopping cart, order processing, admin dashboard or payment gateway.

## Before publishing
Replace sample images, sample text and placeholder contact details with restaurant-approved assets and information. Confirm menu items and prices with the restaurant. Images currently load from Unsplash and therefore require an internet connection.

## Suggested next phases
- Phase 2: live menu data, cart and takeaway checkout UI.
- Phase 3: Node.js/Express API and Firebase Firestore/Storage.
- Phase 4: secure admin dashboard.
- Phase 5: payment gateway integration and end-to-end testing.
